base_params

--------------!!重点：用户需确保下面的Y?_List和Y?_MB_List一一对应!!------------------


Y_List_Cover



Y_MB_List_Cover


--引脚定义
WDT_PIN = "D11"
BLED_PIN = "D7"
GLED_PIN = "D8"
RLED_PIN = "D9"
ETHRST_PIN = "D5"
RS485_PIN = "D0"

--全局变量定义
UpdatePeriodCntMs = 0 --Modbus轮询周期计时器变量(单位:ms)
DelayMsCnt = 0
WaitMsCnt = 0
BlueLedOnCntMs = 0
GreenLedOnCntMs = 0
RedLedOnCntMs = 0

--延时n毫秒函数
function DelayMs(n)
	DelayMsCnt = 0
	while DelayMsCnt < n do
		GC(1)
	end
end

--读取Modbus从机03遥测数据并同步给Iec61850主站
function ModbusToIec61850_YC()
	--逐个轮询YC_MB_List中定义的所有485从机
	for i, mb in ipairs(YC_MB_List) do
		LIB_ModbusToJsonConfig(4096)
		--添加某个485从机下的所有modbus遥测数据点(寄存器)
		for j, data in ipairs(mb.data) do
			LIB_ModbusToJsonAdd(data[2], data[3], data[4], data[1])
		end
		--根据已配置的通信参数, 通过RS485向该485从机获取上面添加的modbus遥测数据
		LIB_ModbusToJsonSend(mb.com[1], mb.com[2], mb.com[3], mb.com[4], mb.com[5], mb.com[6], mb.com[7])
		-- 等待RS485通信结束
		while(GC(1) == true)
		do
			Finish,Data,Err = LIB_ModbusToJsonFinishCheck()
			if Finish == 1 then
				if Data == "null" then --485通信错误
					RedLedOnCntMs = 100 --红灯闪0.1秒
					print(string.format("YC_MB_List[%d]:", i)..Err) --打印日志
				else --成功收到485数据，并生成json字符串形如:{"RTU/GGIO1.AnIn1":28.12, "RTU/GGIO1.AnIn2":26.50, "RTU/GGIO1.AnIn3":27.38...}
					GreenLedOnCntMs = 100 --绿灯闪0.1秒
					print(string.format("YC_MB_List[%d]:", i)..Data)
					for k, yc in ipairs(YC_List) do --遍历某个485从机中的所有61850数据点
						if yc[3] == "FLOAT32" then
							--判断该json中是否包含类似yc[1] = "RTU/GGIO1.AnIn1"的值，并解析出浮点数值
							Json_Val_Float32 = LIB_JsonExDotParse(Data, "$."..yc[1], "Number")
							if Json_Val_Float32 ~= nil then
								--更新61850数据点,例如 "RTU/GGIO1.AnIn1.mag.f"
								LIB_IEC61850OprNode("YC_RM", yc[1]..yc[2], Json_Val_Float32)
							else
								print("json parse "..yc[1].." error")
							end
						elseif yc[3] == "INT32" then
							--判断该json中是否包含类似yc[1] = "RTU/GGIO1.Inc1"的值，并解析出整型数值
							Json_Val_Int32 = LIB_JsonExDotParse(Data, "$."..yc[1], "Int32")
							if Json_Val_Int32 ~= nil then
								--更新61850数据点,例如 "RTU/GGIO1.Inc.stVal"
								LIB_IEC61850OprNode("YC_RM", yc[1]..yc[2], Json_Val_Int32)
							else
								print("json parse "..yc[1].." error")
							end
						end
					end
				end
				DelayMs(mb.com[7]) --延时mb.com[7](每包数据的通信间隔时间ms)
				break --跳出while循环
			end
		end
	end
end

-- 提取指定位的函数
function getBitValue(value, bitStr)
    -- 从字符串 "BITn" 中提取数字 n
    local bitIndex = tonumber(bitStr:match("BIT(%d+)"))
    if bitIndex == nil or bitIndex < 0 or bitIndex > 15 then
        print("bitStr must be BIT0 ~ BIT15")
    end

    -- 提取该位，右移后与1相与
    local bitValue = (value >> bitIndex) & 1
    return bitValue
end

--01/02功能码读取Modbus从机线圈状态或离散输入状态, 03/04读16位寄存器中某个位的的值, 同步给Iec61850主站
function ModbusToIec61850_YX()
	--逐个轮询YX_MB_List中定义的所有485从机
	for i, mb in ipairs(YX_MB_List) do
		--03/04读16位寄存器中某个位的的值
		if mb.com[4] == "03" or mb.com[4] == "04" then
			--配置串口通信，mb.com[1]:波特率, mb.com[2]:校验方式, mb.com[3]:停止位
			LIB_Uart1SetParam( mb.com[1], mb.com[2], mb.com[3])
			last_reg_value = 0
			last_reg_addr = 99999
			--逐个获取每个位的状态值0或1
			for j, data in ipairs(mb.data) do
				--之前没读过的寄存器才有必要读取一次
				if last_reg_addr ~= data[2] then
					last_reg_value = 0
					--mb.com[4]:功能码, mb.com[5]:设备mb地址, data[2]:寄存器地址, 1:读取1个寄存器
					LIB_Uart1BlockSend(LIB_MbRtuMasterSendTrans( mb.com[4], mb.com[5], data[2], 1))
					last_reg_addr = data[2]
					WaitMsCnt = 0
					while WaitMsCnt < mb.com[6] do --应答最长等待时间(ms)
						recv_flag, recv_tab = LIB_Uart1Recv()
						if recv_flag == 1 then
							result,content = LIB_MbRtuMasterRecvTrans(mb.com[4], recv_tab)
							if result> 0 then
								GreenLedOnCntMs = 100 --绿灯闪0.1秒
								--获取1个16位寄存器的值
								last_reg_value = content[1]
								--从这个16位寄存器中获取想要的那个位的值(0或1)
								bit_val = getBitValue(last_reg_value, data[3]) --data[3]: "BIT0"~"BIT15"
								--更新61850数据点,例如 "RTU/GGIO1.Ind1.stVal"
								LIB_IEC61850OprNode("YX_RS", data[1]..".stVal", bit_val)
							else
								RedLedOnCntMs = 100 --红灯闪0.1秒
								print(string.format("YX_MB_List.data[%d]: modbus send fail, re=%d", j, result))
							end
							DelayMs(mb.com[7]) --延时mb.com[7](每包数据的最小通信间隔时间ms)
							break
						end
					end
					
					if WaitMsCnt >= mb.com[6] then --通信超时
						RedLedOnCntMs = 100 --红灯闪0.1秒
						print(string.format("YX_MB_List.data[%d]: modbus send timeout!", j))
					end
				--上次已经读过这个寄存器了
				else
					--从上次读取的那个16位寄存器中获取想要的那个位的值(0或1)
					bit_val = getBitValue(last_reg_value, data[3]) --data[3]: "BIT0"~"BIT15"
					--更新61850数据点,例如 "RTU/GGIO1.Ind1.stVal"
					LIB_IEC61850OprNode("YX_RS", data[1]..".stVal", bit_val)
				end
			end
		--01/02 读线圈or读离散输入
		else
			LIB_ModbusToJsonConfig(4096)
			--添加某个485从机下的所有modbus遥测数据点(寄存器)
			for j, data in ipairs(mb.data) do
				LIB_ModbusToJsonAdd(data[2], data[3], data[4], data[1])
			end
			--根据已配置的通信参数, 通过RS485向该485从机获取上面添加的modbus遥测数据
			LIB_ModbusToJsonSend(mb.com[1], mb.com[2], mb.com[3], mb.com[4], mb.com[5], mb.com[6], mb.com[7])
			-- 等待RS485通信结束
			while(GC(1) == true)
			do
				Finish,Data,Err = LIB_ModbusToJsonFinishCheck()
				if Finish == 1 then
					if Data == "null" then --485通信错误
						RedLedOnCntMs = 100 --红灯闪0.1秒
						print(string.format("YX_MB_List[%d]:", i)..Err) --打印日志
					else --成功收到485数据，并生成json字符串形如:{"RTU/GGIO1.Ind1":0, "RTU/GGIO1.Ind2":0, "RTU/GGIO1.Ind3":1...}
						GreenLedOnCntMs = 100 --绿灯闪0.1秒
						print(string.format("YX_MB_List[%d]:", i)..Data)
						for k, yx in ipairs(YX_List) do --遍历某个485从机中的所有61850数据点
							--判断该json中是否包含类似yx[1] = "RTU/GGIO1.Ind1"的值，并解析出0或1值
							Json_Val_0_1 = LIB_JsonExDotParse(Data, "$."..yx[1], "Int32")
							if Json_Val_0_1 ~= nil then
								--更新61850数据点,例如 "RTU/GGIO1.Ind1.stVal"
								LIB_IEC61850OprNode("YX_RS", yx[1]..yx[2], Json_Val_0_1)
							else
								print("json parse "..yx[1].." error")
							end
						end
					end
					DelayMs(mb.com[7]) --延时mb.com[7](每包数据的通信间隔时间ms)
					break --跳出while循环
				end
			end
		end
	end
end

--将Iec61850主站下发的遥控信号，转换为Modbus 05功能码写从机线圈操作
function ModbusToIec61850_YK()
	--查询是否收到遥控指令
	ret,val = LIB_IEC61850OprNode("YK_RC")
	if ret ~= nil then --ret的值类似为："RTU/GGIO1.SPCSO1"
		DelayMs(250) --延时250ms，错开uart和61850 spi 
		--遍历YK_MB_List中定义的所有485从机，查找出是哪个从机需要执行遥控指令
		for i, mb in ipairs(YK_MB_List) do
			--遍历某个从机下面的所有线圈
			for j, data in ipairs(mb.data) do
				--判断是不是需要控制的那个线圈
				if data[1] == ret then
					--通过 Uart1 口下发modbus 05数据指令包
					LIB_Uart1SetParam(mb.com[1], mb.com[2], mb.com[3])
					LIB_Uart1BlockSend(LIB_MbRtuMasterSendTrans(mb.com[4], mb.com[5], data[2], val))
					DelayMs(mb.com[7]) --延时mb.com[7](每包数据的通信间隔时间ms)
				end
			end

		end
	end
end

--将Iec61850主站下发的遥调数值(浮点数)，转换为Modbus 10功能码写从机2个寄存器的操作
function ModbusToIec61850_YT()
	--查询是否收到遥调指令
	ret, float32_val = LIB_IEC61850OprNode("YT_RR")
	if ret ~= nil then --ret的值类似为："RTU/GGIO1.SPCSO1"
		DelayMs(250) --延时250ms，错开uart和61850 spi 
		--遍历YT_MB_List中定义的所有485从机，查找出是哪个从机需要执行遥控指令
		for i, mb in ipairs(YT_MB_List) do
			--遍历某个从机下面的所有遥调数据点
			for j, data in ipairs(mb.data) do
				--判断是不是需要控制的那个遥调数据点
				if data[1] == ret then
					--通过 Uart1 口下发modbus 10数据
					LIB_Uart1SetParam(mb.com[1], mb.com[2], mb.com[3])
					
					tab = {}
					if data[3] == "F_ABCD" then
						val1,val2 = LIB_BC("F32_BYTE16", float32_val)
						tab[1] = val1
						tab[2] = val2
					elseif data[3] == "F_CDAB" then
						val1,val2 = LIB_BC("F32_BYTE16", float32_val)
						tab[1] = val2
						tab[2] = val1
					elseif data[3] == "L_ABCD" then
						int32_val = math.floor(float32_val)
						val1,val2 = LIB_BC("I32_BYTE16", int32_val)
						tab[1] = val1
						tab[2] = val2
					elseif data[3] == "L_CDAB" then
						int32_val = math.floor(float32_val)
						val1,val2 = LIB_BC("I32_BYTE16", int32_val)
						tab[1] = val2
						tab[2] = val1
					elseif data[3] == "S_AB" then
						int16_val = math.floor(float32_val)
						val1 = LIB_BC("I16_BYTE16", int16_val)
						tab[1] = val1
					else

					end
					--以modbus 10功能码(写多个寄存器)数据格式发送，连续写入两个寄存器
					LIB_Uart1BlockSend(LIB_MbRtuMasterSendTrans(mb.com[4], mb.com[5], data[2], tab))
					DelayMs(mb.com[7]) --延时mb.com[7](每包数据的通信间隔时间ms)
				end
			end
		end
	end
end


--定义10毫秒定时器的回调函数，函数名字必须是LIB_10msTimerCallback
function LIB_10msTimerCallback()
	UpdatePeriodCntMs = UpdatePeriodCntMs + 10
	DelayMsCnt = DelayMsCnt + 10
	WaitMsCnt = WaitMsCnt + 10
	--喂狗
	LIB_GpioToggle(WDT_PIN)
	--led灯闪烁时长处理
	if BlueLedOnCntMs > 0 then
		BlueLedOnCntMs = BlueLedOnCntMs - 10
		LIB_GpioWrite(BLED_PIN, 0) --Blue led 亮 
	else
		LIB_GpioWrite(BLED_PIN, 1) --Blue led 灭
	end
	if GreenLedOnCntMs > 0 then
		GreenLedOnCntMs = GreenLedOnCntMs - 10
		LIB_GpioWrite(GLED_PIN, 0) --Green led 亮
	else
		LIB_GpioWrite(GLED_PIN, 1) --Green led 灭
	end
	if RedLedOnCntMs > 0 then
		RedLedOnCntMs = RedLedOnCntMs - 10
		LIB_GpioWrite(RLED_PIN, 0) --Red led 亮
	else
		LIB_GpioWrite(RLED_PIN, 1) --Red led 灭
	end
	--61850处于连接状态时且其它颜色灯不占用时，蓝灯一直亮
	if LIB_IEC61850NetIsConnect() == 1 and GreenLedOnCntMs <= 0 and RedLedOnCntMs <= 0 then
		BlueLedOnCntMs = 1000
	else
		BlueLedOnCntMs = 0
	end
end

--以下代码开始初始化
LIB_LuaTfLogDisable()
LIB_UsbConfig("CDC")--开启usb打印功能
--将sys red led和sys green led配置成D9和D8
LIB_SysLedConfig("D9","D8")
--配置D11控制看门狗喂狗引脚
LIB_GpioOutputConfig(WDT_PIN,"STANDARD")
--配置D7,D8,D9控制三色RGB灯的B,G,R引脚
LIB_GpioOutputConfig(BLED_PIN, "STANDARD")
LIB_GpioOutputConfig(GLED_PIN, "STANDARD")
LIB_GpioOutputConfig(RLED_PIN, "STANDARD")
LIB_GpioWrite(BLED_PIN, 1) --Blue led 灭
LIB_GpioWrite(GLED_PIN, 1) --Green led 灭
LIB_GpioWrite(RLED_PIN, 1) --Red led 灭 
--RS485接口初始化
LIB_Uart1Rs485Config("BAUDRATE_115200", RS485_PIN)

--RGB灯闪3下
for i=1, 3 do
	LIB_GpioWrite(GLED_PIN, 0)
	LIB_DelayMs(100)
	LIB_GpioWrite(GLED_PIN, 1)
	LIB_DelayMs(400)
	
	LIB_GpioWrite(BLED_PIN, 0)
	LIB_DelayMs(100)
	LIB_GpioWrite(BLED_PIN, 1)
	LIB_DelayMs(400)
	
	LIB_GpioWrite(RLED_PIN, 0)
	LIB_DelayMs(100)
	LIB_GpioWrite(RLED_PIN, 1)
	LIB_DelayMs(400)
end

--添加所有需要的61850数据点
if YC_List ~= nil then
	LIB_IEC61850AddNode("YC_RM", YC_List)
end
if YX_List ~= nil then
	LIB_IEC61850AddNode("YX_RS", YX_List)
end
if YK_List ~= nil then
	LIB_IEC61850AddNode("YK_RC", YK_List)
end
if YT_List ~= nil then
	LIB_IEC61850AddNode("YT_RR", YT_List)
end
--使能系统10毫秒定时器开始工作
LIB_10msTimerConfig("ENABLE")
--设置W5500以太网模块SPI的MISO,MOSI,CLK,CS占用D1D2D3D4引脚，RST占用D5引脚
--并开启IEC61850 MMS Server服务(TCP Server)
if sntp_enable == 1 then
	LIB_IEC61850ServerStart("SPI_1",ETHRST_PIN,mac,ip,subm,gw,dns,port,keepalive_time,sntp_ip,sntp_port,sntp_interval)
else
	LIB_IEC61850ServerStart("SPI_1",ETHRST_PIN,mac,ip,subm,gw,dns,port,keepalive_time)
end
if net_autofix_enable == 1 then
	--设置如果连续net_autofix_time秒没收到对端任何消息，自动重启整个系统或重启网络
	LIB_IEC61850NetAutoFixCfg(net_autofix_time, net_autofix_way)
end
--进入大循环中
while(GC(1) == true)
do
	--每隔Poll_Time毫秒更新一次遥测和遥信的数据点的值
	if UpdatePeriodCntMs > Poll_Time then
		UpdatePeriodCntMs = 0
		
		if YC_MB_List ~=nil then
			--读取Modbus从机遥测数据并同步数据给Iec61850主站
			ModbusToIec61850_YC()
		end
		if YX_MB_List ~=nil then
			--读取Modbus从机遥信数据并同步数据给Iec61850主站
			ModbusToIec61850_YX()
		end
	end
	if YK_MB_List ~=nil then
		--从Iec61850主站接收遥控指令并同步给modbus从机
		ModbusToIec61850_YK()
	end
	if YT_MB_List ~=nil then
		--从Iec61850主站接收遥调数据并同步给modbus从机
		ModbusToIec61850_YT()
	end
	if net_autofix_enable == 1 then
		LIB_IEC61850NetFixDeamon()
	end
end